package coursera;

public class Serie extends Netflix implements IVisualizable, Comparable {
	
	private int	   	no_de_temporadas;
	
	public Serie(String titulo, String creador) {
		super(titulo, creador);
		// TODO Auto-generated constructor stub
	}
	
	public Serie(String titulo, String genero, String creador, int duracion, int no_de_temporadas) {
		super(titulo, genero, creador, duracion);
		// TODO Auto-generated constructor stub
		this.no_de_temporadas = no_de_temporadas;
	}

	/**
	 * @return the no_de_temporadas
	 */
	public int getNo_de_temporadas() {
		return no_de_temporadas;
	}

	/**
	 * @param no_de_temporadas the no_de_temporadas to set
	 */
	public void setNo_de_temporadas(int no_de_temporadas) {
		this.no_de_temporadas = no_de_temporadas;
	} 
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		System.out.println(no_de_temporadas+" temporadas\nDescripci�n:");
		return super.toString();
		
	}

	
	public boolean marcarVisto() {
		setVisto(!isVisto());
		return isVisto();
	}

	public void esVisto() {
		System.out.println("Ha visto esta serie: " + isVisto());
	}

	public void tiempoVisto(String tiempo) {
		String tiempo_visto = "El tiempo visto"+tiempo;
	}
	
	public int compareTo(Object obje){
		Serie serie = (Serie) obje;
		if (this.no_de_temporadas<serie.no_de_temporadas){
			return 1;
		}
		if (this.no_de_temporadas>serie.no_de_temporadas){
			return -1;
		}
		return 0;
	}
}
