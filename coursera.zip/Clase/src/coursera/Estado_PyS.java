package coursera;

import java.util.Arrays;

public class Estado_PyS {
	
	public static void main(String[] args){
		
		int i;
		Pelicula[] misPeliculas = new Pelicula[5];
		Serie[] misSeries = new Serie[5];
		
		misPeliculas[0] = new Pelicula("La sirenita", "Infantil", "Walt Disney", 85, 1989);
		misPeliculas[1] = new Pelicula("Sexto sentido","Suspenso", "Shyamalan", 107, 1999);
		misPeliculas[2] = new Pelicula("Eso", "Terror", "Stephen King", 115, 1990);
		misPeliculas[3] = new Pelicula("Star Wars: Episodio III", "Ciencia ficci�n", "George Lucas" , 139, 2005);
		misPeliculas[4]	= new Pelicula("Up", "Bob Peterson");
		
		misSeries[0] = new Serie("Super Campeones", "Anime", "Isamu Imakake", 20, 3);
		misSeries[1] = new Serie("Sailor Moon", "Anime", "Junichi Sato", 20, 5);
		misSeries[2] = new Serie("Dragon Ball Super", "Anime", " Akira Toriyama", 20, 1);
		misSeries[3] = new Serie("Bones", 	"Hart Hanson");
		misSeries[4] = new Serie("Game of Thrones", "Fantasia", "David Benioff", 50, 7);
				
		misSeries[1].marcarVisto();
		misSeries[1].tiempoVisto("18:20 min");
		misSeries[4].marcarVisto();
		misSeries[4].tiempoVisto("45:27 min");
		misPeliculas[0].marcarVisto();
		misPeliculas[0].tiempoVisto("85:00 min");
		misPeliculas[2].marcarVisto();
		misPeliculas[2].tiempoVisto("97:07 min");
		misPeliculas[3].marcarVisto();
		misPeliculas[3].tiempoVisto("130:17 min");
		
		System.out.println(misSeries[1].tiempoVisto());
		
		/*System.out.println("Las series que has visto son:");
		for(i=0; i<5;i++){
			if(misSeries[1].isVisto()=true){
				System.out.println(misSeries[i].toString());
			}
		}
		
		/*System.out.println("Peliculas vistas:");
		for(i=0; i<5;i++){
			if(misSeries[i].marcarVisto()=true){
				System.out.println(misSeries[i].toString());
			}
		}*/
		
		System.out.println("La serie con m�s temporadas tiene:");
		Arrays.sort(misSeries);
		System.out.println(misSeries[0].toString());
		
		System.out.println("La pel�cula m�s actual es del a�o:");
		Arrays.sort(misPeliculas);
		System.out.println(misPeliculas[0].toString());
		
	}

}
