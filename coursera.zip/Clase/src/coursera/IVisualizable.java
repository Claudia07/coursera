package coursera;

public interface IVisualizable {
		
	public boolean marcarVisto();
	
	public void esVisto();
	
	public void tiempoVisto();

}
