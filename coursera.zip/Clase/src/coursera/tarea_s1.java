package coursera;

import java.util.Scanner;

public class tarea_s1 {
	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);
		int i,j;
		int[][] matriz = new int[4][4];
		
		for(i=0; i<4; i++){
			
			System.out.println();
			
			for(j=0; j<4; j++){
				matriz[i][j]=2*(j+1)+(8*i);
				System.out.print(matriz[i][j]+"\t");
			}
			
		}
		
	}

}
