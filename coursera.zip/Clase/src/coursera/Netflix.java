package coursera;

public class Netflix {
	
	private String 	titulo;
	private String 	genero;
	private String 	creador;
	private int	duracion;
	private boolean visto;
	
	public Netflix(){
		
		this.visto = false;
	}
	
	public Netflix(String titulo, String creador){
		
		this.titulo = 	titulo;
		this.creador = 	creador;
		
	}
	
	public Netflix(String titulo, String genero, String creador, int duracion) {
		
		this.titulo = titulo;
		this.genero = genero;
		this.creador = creador;
		this.duracion = duracion;
	
	}	
	
	/**
	 * @return the titulo
	 */
	public String getTitulo() {
		return titulo;
	}
	/**
	 * @param titulo the titulo to set
	 */
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	/**
	 * @return the genero
	 */
	public String getGenero() {
		return genero;
	}
	/**
	 * @param genero the genero to set
	 */
	public void setGenero(String genero) {
		this.genero = genero;
	}
	/**
	 * @return the creador
	 */
	public String getCreador() {
		return creador;
	}
	/**
	 * @param creador the creador to set
	 */
	public void setCreador(String creador) {
		this.creador = creador;
	}
	/**
	 * @return the duracion
	 */
	public int getDuracion() {
		return duracion;
	}
	/**
	 * @param duracion the duracion to set
	 */
	public void setDuracion(int duracion) {
		this.duracion = duracion;
	}
	
	public boolean isVisto() {
		return visto;
	}

	public void setVisto(boolean visto) {
		this.visto = visto;
	}

	public String toString(){
		
		String informacion;
		informacion= "T�tulo: "+ titulo + "\nG�nero: "+ genero 
					+ "\nCreador: "+ creador + "\nDuraci�n: " + duracion;
		return informacion;		
	}
	
}
