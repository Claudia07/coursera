package coursera;

public class Pelicula extends Netflix implements IVisualizable, Comparable{
	
	private int	   	anio;
	
	public Pelicula(String titulo, String creador) {
		super(titulo, creador);
		// TODO Auto-generated constructor stub
	}
	
		
	public Pelicula(String titulo, String genero, String creador, int duracion, int anio) {
		super(titulo, genero, creador, duracion);
		// TODO Auto-generated constructor stub
		this.anio = anio;
	}

	public int getAnio() {
		return anio;
	}

	public void setAnio(int anio) {
		this.anio = anio;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		System.out.println(anio+"\nDescripci�n:");
		return super.toString();
	}

	public boolean marcarVisto() {
		setVisto(!isVisto());
		return isVisto();
	}

	public void esVisto() {
		System.out.println("Ha visto esta serie: " + isVisto());
	}

	public void tiempoVisto(String tiempo) {
		String tiempo_visto = "El tiempo visto"+tiempo;
	}
	
	public int compareTo(Object obje){
		Pelicula peli = (Pelicula) obje;
		if (this.anio<peli.anio){
			return 1;
		}
		if (this.anio>peli.anio){
			return -1;
		}
		return 0;
	}

}
